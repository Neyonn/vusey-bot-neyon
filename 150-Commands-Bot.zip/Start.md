1 . npm install canvas
2 . npm install canvas -g
3 . node index.js